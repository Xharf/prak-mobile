package com.example.pertemuan42x

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
